package com.luban.security01.config;

import com.luban.security01.service.MyUserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * @author Fox
 */
@Configuration
//@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    private UserDetailsService myUserDetailsService;

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
//        auth.inMemoryAuthentication()
//                .withUser("fox")
//                .password(passwordEncoder().encode("123456"))
//                .authorities("admin").and()
//                .withUser("fox2")
//                .password(passwordEncoder().encode("123456"))
//                .authorities("admin");
        auth.userDetailsService(myUserDetailsService);
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.formLogin()  //表达登录
            .loginPage("/login.html") //指定登录路径
            .loginProcessingUrl("/user/login")  // 对应 action="/user/login"
            .defaultSuccessUrl("/main.html");
            //.failureHandler()

        //授权
        http.authorizeRequests()
                // 不用认证
                .antMatchers("/login.html","/user/login").permitAll()
                .anyRequest().authenticated();  //认证

       // http.csrf().disable();//csrf关掉
//                .

    }

    @Bean
    public PasswordEncoder passwordEncoder(){
        return new BCryptPasswordEncoder();
    }

//    @Bean
//    @Override
//    public UserDetailsService userDetailsServiceBean() throws Exception {
//        return new MyUserDetailsService();
//    }
}
