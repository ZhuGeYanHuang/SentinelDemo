package com.luban.bean;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.Set;


@Data
public class UserDto {
    public static final String SESSION_USER_KEY = "user_";

    private String id;
    private String username;
    private String password;
    private String fullname;
    private String mobile;
    /**
     * 用户权限
     */
    private Set<String> authorities;
}
