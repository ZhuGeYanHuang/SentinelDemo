package com.luban.bean;

import lombok.Data;

/**
 * @author Fox
 * 认证请求参数
 */
@Data
public class AuthenticationRequest  {

    private String username;

    private String password;
}
