package com.luban.service;

import com.luban.bean.AuthenticationRequest;
import com.luban.bean.UserDto;

/**
 * @author Fox
 */
public interface AuthenticationService {
    /**
     * 用户认证
     * @param authenticationRequest
     * @return
     */
    UserDto authentication(AuthenticationRequest authenticationRequest);
}
