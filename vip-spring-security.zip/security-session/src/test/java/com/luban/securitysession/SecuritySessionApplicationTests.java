package com.luban.securitysession;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecuritySessionApplicationTests {

    @Test
    void contextLoads() {
    }

}
