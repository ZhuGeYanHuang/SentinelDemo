package com.luban.securitysession;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecuritySessionApplication {

    public static void main(String[] args) {
        SpringApplication.run(SecuritySessionApplication.class, args);
    }

}
