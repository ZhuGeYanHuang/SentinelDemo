package com.luban.security03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Security03ApplicationTests {

    @Test
    void contextLoads() {
    }

}
