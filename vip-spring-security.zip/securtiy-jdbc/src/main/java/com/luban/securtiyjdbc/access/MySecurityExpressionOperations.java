package com.luban.securtiyjdbc.access;

import org.springframework.security.core.Authentication;

import javax.servlet.http.HttpServletRequest;

/**
 * @author Fox
 */
public interface MySecurityExpressionOperations {

    boolean hasPermission(HttpServletRequest request, Authentication authentication);
}
